# Project: Project Diamond - App1 Unit Testing
# Purpose Details: Unit Test to confirm methods are functioning for App1.py
#		   Ensures the app returns a valid JSON payload
#		   Ensures it actually writes a file
#		   Is able to send payload to App2.py via mock SSL socket
# Course: HCDD 411
# Author: William Perez
# Due Date: 12 October, 2025
# Date Developed: 10/11/2025
# Last Date Changed: 10/11/2025
# Rev: 1

import unittest
from unittest.mock import patch, MagicMock
import json
import tempfile
import os
import App1
import io

class TestApp1(unittest.TestCase):

    @patch("urllib.request.urlopen")
    @patch("sys.stdout", new_callable=io.StringIO) #Removes print executables from App1.py from printing on unit test.
    def test_retrieveJSONPayload(self, mock_stdout, mock_urlopen):
        # Mock HTTP response
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps([{"id": 1, "name": "test"}]).encode("utf-8")
        mock_urlopen.return_value = mock_response

        p = App1.Payload(1, "http://example.com/data")
        data = p.retrieveJSONPayload()

        self.assertIsInstance(data, list)
        self.assertEqual(data[0]["name"], "test")

    def test_saveJSONtoFile(self):
        payload = {"test": True}
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            App1.saveJSONtoFile(payload, tmp.name)
            tmp_path = tmp.name

        with open(tmp_path, "r") as f:
            data = json.load(f)

        self.assertTrue(data["test"])
        os.remove(tmp_path)

    @patch("socket.socket")
    @patch("ssl.wrap_socket")
    @patch("sys.stdout", new_callable=io.StringIO)
    def test_sendPayloadToApp2(self, mock_stdout, mock_wrap_socket, mock_socket):
        mock_ssl = MagicMock()
        mock_wrap_socket.return_value = mock_ssl

        payload = {"id": 1, "msg": "hello"}
        App1.sendPayloadToApp2(payload)

        mock_wrap_socket.assert_called_once()
        mock_ssl.sendall.assert_called()
        mock_ssl.close.assert_called()

if __name__ == "__main__":
    unittest.main()
