"""
test_app5.py - Basic unit tests for App5 logging service (Eve REST API)
Course: HCDD 411
Author: Team 2 (Project Diamond)
Purpose:
    Test that App5 can accept and return log records
"""

# Project: Project Diamond - App5 Tests
# Author: Team 2 (Williams)
# Date Developed: 11/30/2025
# Last Modified: 11/30/2025
# Purpose: Simple REST API tests using urllib
# Rev: 1

import unittest
import json
from urllib import request, error


BASE_URL = "http://127.0.0.1:5050/log"


class TestApp5Logging(unittest.TestCase):
    """
    Tests for App5:
    1. Can we POST a log entry?
    2. Can we GET log entries back?
    """

    def test_create_log_entry(self):
        """Test that POST /log creates a new log document."""
        payload = {
            "activity": "unit_test_log",
            "status": "pass",
            "timestamp": "2025-11-03T00:00:00Z",
            "details": {"source": "test_app5.py"}
        }

        data = json.dumps(payload).encode("utf-8")
        req = request.Request(
            BASE_URL,
            data=data,
            headers={"Content-Type": "application/json"}
        )

        try:
            with request.urlopen(req) as resp:
                self.assertTrue(200 <= resp.status < 300)
        except Exception as e:
            self.fail(f"POST /log failed: {e}")

    def test_get_logs(self):
        """Test that GET /log returns list of log items."""
        try:
            with request.urlopen(BASE_URL) as resp:
                self.assertEqual(resp.status, 200)
                body = resp.read().decode("utf-8")
                data = json.loads(body)
                self.assertIn("_items", data)
                self.assertIsInstance(data["_items"], list)
        except Exception as e:
            self.fail(f"GET /log failed: {e}")


if __name__ == "__main__":
    unittest.main()
