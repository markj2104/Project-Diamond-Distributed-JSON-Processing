# Project: Project Diamond - App2 Unit Testing
# Purpose Details: Unit Test to confirm methods are functioning for App2.py
#                  Ensures App2 correctly saves incoming JSON payloads,
#                  posts logs to the Eve server (mocked),
#                  and runs TLS socket server logic safely using mocks.
# Course: HCDD 411
# Author: William Perez
# Due Date: 12 October, 2025
# Date Developed: 10/11/2025
# Last Date Changed: 10/11/2025
# Rev: 1

import unittest
from unittest.mock import patch, MagicMock, mock_open, call
from urllib.error import URLError
import json
import tempfile
import os
import App2

class TestApp2(unittest.TestCase):

    def test_save_json_to_file(self):
        data = {"x": 1, "y": 2}
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            App2.save_json_to_file(data, tmp.name)
            tmp_path = tmp.name

        with open(tmp_path) as f:
            result = json.load(f)
        self.assertEqual(result, data)
        os.remove(tmp_path)

    @patch("urllib.request.urlopen")
    def test_post_log_success(self, mock_urlopen):
        mock_response = MagicMock()
        mock_response.status = 201
        mock_urlopen.return_value.__enter__.return_value = mock_response
        success = App2.post_log("test_event", "pass")
        self.assertTrue(success)

    @patch("urllib.request.urlopen", side_effect=URLError("connection error"))
    def test_post_log_failure(self, mock_urlopen):
        success = App2.post_log("test_event", "fail")
        self.assertFalse(success)

    def test_recv_all(self):
        fake_socket = MagicMock()
        fake_socket.recv.side_effect = [b"part1", b"part2", b""]
        result = App2.recv_all(fake_socket)
        self.assertEqual(result, b"part1part2")

# ---------------- New Tests for Hashing and SFTP integration ----------------
    def test_generate_HASHsignature_valid(self):
        msg = {"data": "test message"}
        key = "team2"
        sig1 = App2.generate_HASHsignature(msg, key)
        sig2 = App2.generate_HASHsignature(msg, key)

        self.assertIsInstance(sig1, str)
        self.assertEqual(sig1, sig2)
        self.assertEqual(len(sig1), 64)  # SHA256 hex digest is 64 chars

    def test_generate_HASHsignature_error_handling(self):
        bad_msg = {"data": set([1, 2, 3])}  # sets aren't JSON serializable
        key = "team2"
        sig = App2.generate_HASHsignature(bad_msg, key)
        self.assertIsNone(sig)

    @patch("App2.getpass.getpass", return_value="test_password")
    def test_sendUsingSFTPToApp3_handles_errors(self, mock_getpass):
        test_payload = {"test": "data"}
        test_hash = "testhash123"

        # Mock ALL pysftp operations to prevent any real SFTP attempts
        with patch("App2.pysftp") as mock_pysftp:
            # Mock the connection to raise an exception (simulating connection failure)
            mock_pysftp.Connection.side_effect = Exception("SFTP connection failed")
            mock_pysftp.CnOpts.return_value.hostkeys = None

            # Mock file operations
            with patch("builtins.open", mock_open()):
                with patch("json.dump"):
                    try:
                        App2.sendUsingSFTPToApp3(test_payload, test_hash)
                        success = True
                    except Exception as e:
                        success = False
                        self.fail(f"Function should handle exceptions internally: {e}")

        self.assertTrue(success)

if __name__ == "__main__":
    unittest.main()
