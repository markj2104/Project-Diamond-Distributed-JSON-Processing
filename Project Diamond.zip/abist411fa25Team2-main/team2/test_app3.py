# Project: Project Diamond - App3 Unit Testing
# Purpose Details: Unit tests to confirm that App3.py correctly downloads,
#                  verifies, and emails the secure JSON payload received
#                  from App2. Tests cover HMAC verification, SFTP download
#                  simulation, and threaded email sending.
# Course: HCDD 411
# Author: William Perez
# Due Date: 2 November, 2025
# Date Developed: 10/30/2025
# Last Date Changed: 10/31/2025
# Rev: 1

import unittest
from unittest.mock import patch, MagicMock
import json
import os
import App3
import hmac as _hmac
import hashlib

class TestApp3(unittest.TestCase):

    def setUp(self):
        self.payload = {"hello": "world"}
        # App3.verify_hmac expects HMAC hex string
        msg_bytes = json.dumps(self.payload, sort_keys=True).encode('utf-8')
        self.hmac_hex = _hmac.new(App3.HMAC_KEY, msg_bytes, hashlib.sha256).hexdigest()

    def test_verify_hmac_success(self):
        ok = App3.verify_hmac(self.payload, self.hmac_hex)
        self.assertTrue(ok)

    def test_verify_hmac_failure(self):
        bad = App3.verify_hmac(self.payload, "badvalue")
        self.assertFalse(bad)

    @patch("App3.pysftp.Connection")
    @patch("App3.getpass.getpass", return_value="dummy_password")
    def test_download_payload_calls_get(self, mock_getpass, mock_conn):
        """Test that download_payload uses pysftp to download file."""
        mock_sftp = MagicMock()
        mock_conn.return_value.__enter__.return_value = mock_sftp

        # Ensure local file removed before test
        if os.path.exists(App3.LOCAL_PATH):
            os.remove(App3.LOCAL_PATH)

        App3.download_payload(username="user", password="pw")
        mock_sftp.get.assert_called_once_with(App3.REMOTE_PATH, App3.LOCAL_PATH)

    @patch("App3.smtplib.SMTP_SSL")
    def test_send_email_uses_smtp_ssl(self, mock_smtp_ssl):
        mock_smtp = MagicMock()
        mock_smtp_ssl.return_value.__enter__.return_value = mock_smtp

        App3.send_email("someone@example.com", "subj", "body")
        mock_smtp.sendmail.assert_called_once()

    @patch("App3.send_email")
    def test_send_emails_threaded_calls_send_email(self, mock_send_email):

        App3.send_emails_threaded("subject", "body")

        self.assertTrue(mock_send_email.call_count >= len(App3.TEAM_EMAILS))

if __name__ == "__main__":
    unittest.main()
