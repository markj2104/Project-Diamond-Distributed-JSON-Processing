# Project: Project Diamond - App4 Unit Testing
# Purpose: Verify App4 receives Pyro object payload and converts it to JSON
# Course: HCDD 411
# Author: William Perez
# Date Developed: 11/25/2025
# Rev: 2

import unittest
from unittest.mock import patch, MagicMock
import json

# Import App4 safely by mocking daemon before import
with patch("Pyro4.Daemon") as mock_daemon:
    fake_daemon = MagicMock()
    fake_daemon.register.return_value = "PYRO_FAKE_URL"
    fake_daemon.requestLoop = MagicMock()   # prevent infinite loop
    mock_daemon.return_value = fake_daemon
    import App4   # import now with daemon mocked


class TestApp4(unittest.TestCase):

    @patch("builtins.print")
    def test_get_JSON_valid_payload(self, mock_print):
        receiver = App4.Reciever()
        payload = {"employee": "John", "access": True}

        result = receiver.get_JSON(payload)
        self.assertIsNone(result)

        expected_json = json.dumps(payload)
        mock_print.assert_any_call("Payload received from APP3:", expected_json)
        print("[OK] get_JSON valid payload works.")

    @patch("builtins.print")
    def test_get_JSON_empty_payload(self, mock_print):
        receiver = App4.Reciever()
        payload = {}

        result = receiver.get_JSON(payload)
        self.assertIsNone(result)

        expected_json = json.dumps(payload)
        mock_print.assert_any_call("Payload received from APP3:", expected_json)
        print("[OK] get_JSON empty payload works.")

    @patch("Pyro4.Daemon")
    def test_daemon_starts_and_registers_reciever(self, mock_daemon):
        """Verify daemon initialization and receiver registration."""
        fake_daemon = MagicMock()
        fake_daemon.register.return_value = "PYRO_FAKE_URL"
        fake_daemon.requestLoop = MagicMock()
        mock_daemon.return_value = fake_daemon

        import importlib
        importlib.reload(App4)

        mock_daemon.assert_called_with(host="0.0.0.0", port=9090)
        fake_daemon.register.assert_called_with(App4.Reciever, objectId="app4.receiver")
        fake_daemon.requestLoop.assert_called_once()
        print("[OK] Daemon initialized, registered Reciever, and requestLoop invoked.")


if __name__ == "__main__":
    unittest.main()
