import socket, ssl, json

HOST = "127.0.0.1"
PORT = 8080

with open("jsonDataFile.txt", "r") as f:
	payload = f.read()

context = ssl.create_default_context()
context.check_hostname = False
context.verify_mode = ssl.CERT_NONE

with socket.create_connection((HOST, PORT)) as sock:
	with context.wrap_socket(sock, server_hostname=HOST) as ssock:
		print("Connected using:", ssock.version())
		ssock.sendall(payload.encode("utf-8"))
		print("Payload sent successfully.")
